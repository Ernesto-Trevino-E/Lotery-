#loteria
import random
from PIL import Image
def endRepeat():
    starter = input('Quieres volver jugar a la loteria <si><no>?: ')
    
    if (starter == 'si'):
        loteria()
        
    elif(starter == 'no'):
        exit()


def loteria():
    lotenomb = ['El gallo', 'El diablo', 'La dama', 'El catrin', 'El paraguas', 'La sirena', 'La escalera', 'La botella', 'El barril', 'El arbol', 'El melon', 'El valiente', 'El gorrito', 'La muerte', 'La pera', 'La bandera', 'El bandolon', 'El violoncello', 'La garza', 'El pajaro', 'La mano', 'La bota', 'La luna', 'El cotorro', 'El borracho', 'El negrito', 'El corazon', 'La sandia', 'El tambor', 'El camaron', 'Las jaras', 'El musico', 'La arana', 'El soldado', 'La estrella', 'El cazo', 'El mundo', 'El apache', 'El nopal', 'El alacran', 'La rosa', 'La calavera', 'La campana', 'El cantarito', 'El venado', 'El sol', 'La corona', 'La chalupa', 'El pino', 'El pescado', 'La palma', 'La maceta', 'El arpa', 'La rana']
    lotenum = []
    for i in range (54):
        lotenum.append(i)
    random.shuffle(lotenum)
    print(lotenomb)
    
    starter = input('Quieres jugar a la loteria <si><no>?: ')
    if (starter == 'si'):
        print(lotenum)
        for k in range(0,54):
            print(lotenomb[lotenum[k]])
            e = str(lotenum[k])+'.jpg'
            try:
                imagen = Image.open(e)
                imagen.show()
            
            except:
                print('No ha sido posible cargar la imagen')
                
            starter = input('Para terminar este juego teclea <loteria>: ')
            
            if (starter == 'loteria'):
                endRepeat()
            
loteria()