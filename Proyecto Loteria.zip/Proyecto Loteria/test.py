from PIL import Image
n = input()
e = str(n) + '.jpg'
image = Image.open(e)
image.show()